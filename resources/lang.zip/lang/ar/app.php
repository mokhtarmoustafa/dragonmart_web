<?php
/**
 * Created by PhpStorm.
 * User: mohammedsobhei
 * Date: 11/7/18
 * Time: 8:34 PM
 */

return [
    'success' => 'تم التنفيذ بنجاح',
    'error' => 'حدث خطأ',
    'updated' => 'نجحت عملية التحديث',
    'not_updated' => 'فشلت عملية التحديث',
    'created' => 'نجحت عملية الانشاء',
    'not_created' => 'فشلت عملية الانشاء',
    'not_deleted' => 'فشلت عملية الحذف',
    'deleted' => 'تمت عملية الحذف بنجاح',
    'waiting' => 'انتظار',

    'not_data_found' => 'لا يوجد بيانات',
    'invalid_token' => 'رمز غير صالح',
    'invalid_route' => 'رابط غير صالح',
    'client_input_error' => 'حدث خطأ من المستخدم',
    'server_error' => 'حدث خطأ من السيرفر',

    'off'=>'خصم',
    'shop_now'=>'تسوق الآن',
    'view_ad'=>'عرض الاعلان',
    'only'=>'فقط',

    'error_confirmation' => 'لم يتم تأكيد رمز التحقق',
    'unauthorized' => 'غير مصرح',

    'pick_up'=>'التسليم باليد',
    'delivery'=>'التوصيل',
    'deliver_method'=>'اختيار طريقة التسليم',
    'no_items'=>'لا يوجد منتجات',
    'cart_shipping'=>'عربة الشحن',

    'activate' => 'تفعيل الحساب',
    'deactivate' => 'تعطيل الحساب',

    'create_rate' => 'تم تقييم منتجك',
    'resend_code_success' => 'تم ارسال رمز التحقق',
    'mobile_updated' => 'تم تعديل رقم الهاتف',

    'verified' => 'تم التحقق',
    'unverified' => 'لم يتم التحقق',
    'user' => 'مستخدم',
    'merchant' => 'محل',
    'city' => 'المدينة',
    'category' => 'التصنيف',
    'price_from' => 'السعر من',
    'price_to' => 'السعر الى',
    'price' => 'السعر',
    'rate' => 'التقييم',
    'service_provider' => 'مزود الخدمة',
    'client' => 'الزبون',

    'driver_created' => 'تم انشاء حساب سائق جديد',
    'user_created' => 'تم انشاء حساب مستخدم جديد',
    'user_updated' => 'تم تحديث بيانات المستخدم',
    'verification_code_error' => 'يوجد خطأ في رمز التحقق',
    'not_verification_code' => 'لم يتم تأكيد رمز التحقق',
    'sent_email_verification' => 'تم ارسال ايميل بتفعيل الحساب',
    'waiting_admin_approved' => 'بانتظار قبول الطلب من الادارة',
    'not_approval' => 'لم يتم قبول الحساب من الادارة',
    'email_updated' => 'سيتم تحديث البريد الإلكتروني الجديد بعد التحقق من بيانات حسابك ،يرجى  التحقق من بريدك الإلكتروني الجديد',
    'shopping_cart' => 'عربة التسوق',
    'continue_shopping' => 'مواصلة التسوق',
    'update_shopping_cart' => 'تحديث سلة الشراء',
    'continue_checkout' => 'أكمل عملية الدفع',
    'cart_items' => 'عناصر العربة',

    'notification' => 'الاشعار',
    'notification_deleted' => 'تم حذف الاشعار',
    'notification_send' => 'تم ارسال الاشعار',
    'notification_not_send' => 'حدثت مشكلة في ارسال الاشعار',

    'product' => 'منتج',
    'service' => 'خدمة',
    'lang' => 'اللغة',

    'contact' => [
        'contact' => 'الاتصال',
        'name' => 'الاسم',
        'email' => 'البريد الالكتروني',
        'title' => 'العنوان',
        'phone' => 'رقم الهاتف',
        'message' => 'نص الرسالة',
        'send_message' => 'ارسل الرسالة',
    ],

    'order' => 'الطلب',
    'status' => 'حالة الطلب',
    'reject_reason' => 'سبب الرفض',
    'driver_source' => 'نوع التوصيل',
    'driver' => 'السائق',

    'address' => 'العنوان',
    'procurement_method' => 'طريقة التوصيل',
    'location' => 'الموقع',
    'received_datetime' => 'تاريخ الاستلام',
    'arrival_date' => 'تاريخ الوصول',
    'schedule_delivery' => 'وقت التسليم',
    'timestamp' => 'تاريخ & وقت',
    

    'mobile' => 'رقم الهاتف',
    'country_code_length' => 'كود الدولة',
    'verification_code' => 'كود التحقق',
    'password' => 'كلمة المرور',

    'display_name' => 'الاسم الظاهر',

    'name' => 'الاسم',
    'username' => 'اسم المستخدم',
    'email' => 'البريد الالكتروني',
    'user_image' => 'صورة المستخدم',
    'logo' => 'صورة',
    'categories' => 'التصنيفات',
    'has_delivery' => 'قابلية التوصيل',

    'vehicle_photo' => 'صورة المركبة',
    'license_driving' => 'رخصة السائق',
    'document' => 'رخصة المركبة',
    'vehicle_id_no' => 'بطاقة تعريف السائق',
    'vehicle_no' => 'رقم لوحة المركبة',
    'vehicle_type_id' => 'نوع المركبة',
    'vehicle_model' => 'موديل المركبة',
    'vehicle_color' => 'لون المركبة',
    'customization' => 'التخصيص',

    'expense_amount' => 'مبلغ المصاريف',
    'expense_date' => 'تاريخ الصرف',
    'apply' => 'أُطلب',

    'notifications' => [
        'user_approved' => 'تم تفعيل حسابك',
        'user_disabled' => 'تم تعطيل حسابك من الادارة',
        'send_order' => 'طلب جديد',
        'accept_order' => 'تمت الموافقة على طلبك',
        'reject_order' => 'تم رفض طلبك :message',
        'canceled_order' => 'تم الغاء الطلب',
        'finished_order' => 'تم تأكيد عملية التسليم من الزبون',
        'accepted_driver' => 'قام السائق بالموافقة على طلب التوصيل',
        'rejected_driver' => 'قام السائق برفض طلب التوصيل',
        'start_navigation' => 'تم البدء بتوصيل الطلب',
        'pickup_driver' => 'تم وصول السائق لمكان استلام الطلب',
        'drop_off_driver' => 'تم وصول السائق لمكان استلام الطلب',
        'rate_product' => 'قام الزبون بتقييم المنتج',
        'rate_service' => 'قام الزبون بتقييم الخدمة',
        'send_service' => 'تم ارسال طلب خدمة من الزبون',
        'accepted_request' => 'تمت الموافقة على طلب الخدمة',
        'rejected_request' => 'تم رفض طلب الخدمة',
        'canceled_request' => 'تم الغاء الطلب من الزبون',
        'finished_request' => 'تم انهاء الطلب',
        'assign_driver' => 'تم تحويل طلب جديد لك من الادارة',
        'notify_merchant_assign_driver' => 'تم تعيين طلبك للسائق :driver_name',
        'chat' => 'رسالة جديدة'
    ],

    'site' => [
        'login_create' => 'تسجيل الدخول / انشاء حساب',
        'sign_up' => 'انشاء حساب',
        'login' => 'تسجيل الدخول',
        'password' => 'كلمة المرور',
        'welcome' => 'مرحبًا بك في حسابك',
        'remember' => 'تذكرني',
        'forget' => 'نسيت رقمك السري؟',
        'user_type' => 'اختر نوع المستخدم',
        'client' => 'العميل',
        'merchant' => 'المحل',
        'provider' => 'مزود الخدمة',
        'name' => 'الاسم',
        'resetpassword' => 'استعادة كلمة المرور',
        'send' => 'ارسال',
        'email_address' => 'البريد الالكتروني',
        'phone' => 'رقم الهاتف',
        'choose_category' => 'اختر التصنيفات',
        'choose_services' => 'اختر الخدمات',
        'choose_city' => 'اختر المدينة',
        'location' => 'الموقع',
        'confirm_password' => 'تأكيد كلمة المرور',
        'submit' => 'تسجيل',

        'choose_location' => 'اختر موقعك',
        'close' => 'اغلق',
        'set_location' => 'حدد موقعك',
        'add_location' => 'اضف موقعك هنا',
        'no_address' => 'لم يتم العثور على اسم عنوان في هذا الموقع',

        'address' => 'العنوان',
        'per_page' => 'لكل صفحة',
        'merchant_name' => 'اسم المحل',

        'services_list' => 'قائمة الخدمات',
        'home' => [
            'categories' => 'التصنيفات',
            'arabic' => 'العربية',
            'register' => 'التسجيل',
            'login' => 'تسجيل الدخول',
            'logout' => 'تسجيل الخروج',
            'all_categories' => 'جميع التصنيفات',
            'search' => 'بحث...',
            'callus' => 'اتصل بنا الآن',
            'cart' => 'العربة',
            'my_orders' => 'طلباتي',

            'home' => 'الرئيسية',
            'merchants' => 'المحلات',
            'services' => 'الخدمات',
            'about_us' => 'من نحن',
            'term' => 'الشروط والاحكام',
            'policy' => 'سياسة الخصوصية',
            'contact_us' => 'اتصل بنا',
            'all_cats' => 'جميع التصنيفات',

            'popular_products' => 'منتجات شائعة',
            'new_products' => 'المنتجات الجديدة',
            'top_selling' => 'الاكثر مبيعاً',
            'view_all' => 'عرض الكل',
            'sar' => 'ر.س',
        ], 'profile' => [
            'account' => 'الحساب',
            'my_account' => 'حسابي',
            'full_name' => 'الاسم كامل',
            'email' => 'البريد الالكتروني',
            'phone' => 'رقم الهاتف',
            'address' => 'العنوان',
            'save' => 'حفظ',
            'order_history' => 'الطلبات السابقة',
            'pending' => 'قيد الانتظار',
            'closed' => 'منتهية',
            'cancelled' => 'ملغاه',
        ],
        'product' => [
            'quick_view' => 'عرض سريع',
            'add_to_cart' => 'اضافة على العربة',
            'add_cart_successfully' => 'تم اضافة المنتج الى العربة بنجاح',
            'remove_from_cart' => 'الحذف من العربة',
            'remove_cart_successfully' => 'تم حذف المنتج من العربة بنجاح',
            'remove_item' => 'حذف المنتج',
            'have' => 'لديك',
            'items_cart' => 'منتجات في العربة',
            'view_cart' => 'عرض العربة',
            'checkout' => 'اتمام الدفع',
            'total' => 'المجموع',
            'clear_cart' => 'تفريغ عربة التسوق',

            'detail' => 'تفصيل',
            'cart_subtotal' => 'اجمالي سعر العربة',
            'offer' => 'العرض',
            'extra_price' => 'السعر الاضافي',
            'unit_price' => 'سعر الوحدة',
            'cart_items' => 'عدد العناصر',

            'quantity' => 'الكمية',
            'total_price' => 'المبلغ الاجمالي',
            'order' => 'طلب',
            'proceed_checkout' => 'أكمل عملية الدفع',
            'reviews' => 'التعليقات',
            'customization' => 'التخصيص',

            'name' => 'اسم المنتج',
            'price' => 'سعر المنتج',
            'original_quantity' => 'الكمية الاصلية',
            'is_offer' => 'قابلية العرض',
            'offer_percentage' => 'نسبة العرض',
            'is_sponsor' => 'قابلية الاعلان',
            'sponsor_duration' => 'مدة الاعلان',
            'category' => 'تصنيف المنتج',
            'custom' => 'التخصيص',
            'custom_price' => 'السعر المخصص',
            'custom_text' => 'العنوان',
            'custom_description' => 'تفصيل',

        ],
        'services' => [
            'services' => 'الخدمات',
            'categories' => 'تصنيف الخدمات',
        ],
        'filter' => [
            'cities' => 'المدن',
            'price' => 'السعر',
            'all_cities' => 'كل المدن',

            'near_by' => 'بالقرب من',
            'apply_filter' => 'تصفية',
            'grid' => 'شبكة',
            'list' => 'قائمة',
            'per_page' => 'لكل صفحة',
            'distance' => 'المسافة',


        ],
        'footer' => [
            'contact_info' => 'معلومات التواصل',
            'address' => 'العنوان',
            'phone' => 'الهاتف',
            'email' => 'البريد الالكتروني',

            'my_account' => 'حسابي',

            'info' => 'معلومات',
            'customer_services' => 'خدمة العملاء',
            'reserve_rights' => 'جميع الحقوق محفوظة',
        ],
        
        
        'CP' =>[
            'Dashboard' => 'لوحة التحكم',
            'home'=> 'لوحة التحكم',
            'New requests'=> 'طلبات جديدة',
            'Finished orders'=> 'طلبات منتهية',
            'Users' => 'المستخدمين',
            'Admins list' => 'الإدارة',
            'Users list' => 'المستخدمون',
            'to'=>'الى',
            'To'=>'الى',
            'Merchant'=>'التاجر',
            'Order #'=>'الطلب #',
            'Merchant name'=>'اسم التاجر',
            'Order date'=>'تاريخ الطلب',
            'Delivery/pickup date'=>'تاريخ التوصيل/التسليم',
            'Roles' => 'الصلاحيات',
            'Delivery method'=>'نوع التوصيل',
            'Choose driver type'=>'اختر نوع التوصيل',
            'Items #'=>'الاصناف #',
            'Procurement method'=>'طريقة الشراء',
            'Reports' => 'التقارير',
            'Revenues list' => 'الإيرادات',
            'Expenses list' => 'المصروفات',
            'Order list' => 'الطلبات',
            'Orders' => 'الطلبات',
            'Order amount (SAR)'=>'مبلغ الطلب (SAR)',
            'Vehicle Type' => 'نوع المركبة',
            'Vehicle Color' => 'لون المركبة',
            'Vehicle Number' => 'رقم المركبة',
            'Status'=> 'الحالة',
            'Driver Type' => 'نوع السائق',
            'Mobile' => 'رقم الهاتف',

            'mobile' => 'رقم الهاتف',
            'Settings' => 'الإعدادات',
            'Categories list' => 'الأقسام',
            'Customizations list' => 'خيارات المنتجات' ,
            'Customizations' => 'خيارات المنتج' ,
            'Shipment list' => 'خيارات الشحن' ,
            'Settings list' => 'الإعدادات العامة',
            'constants' => 'الإعدادات العامة',

            
            'contacts' => 'االدعم',
            
            'advertisements' => 'الإعلانات',
            'Advertisement' => 'الإعلانات',
            
            'Notifications' => 'الإشعارات',
            'Sponsors requests' => 'طلبات الإعلانات',
            'Term' => 'الشروط والاحكام',
            'Privacy' => 'سياسة الخصوصية',
            'About' => 'عنا',
            
            'Profile' => 'حسابي',
            'profile' => 'حسابي',
            
            'New orders' => 'الطلبات الجديده',
            'Current orders' => 'الطلبات الحالية',
            'Completed orders' => 'الطلبات المكتملة',
            
            'Action' => 'عمليات',
            'Add New' => 'إضافة جديد',
            'Delete' => 'حذف',
            
            //Stores
            
            'My Categories' => 'أقسامي',
            'Categories' => 'أقسامي',
            'Category' => 'القسم',
            'Stores' => 'الفروع',
             'save' => 'حفظ',
            'Products' => 'المنتجات',
            
            'New Product' => 'منتج جديد',
            'Add new product' => 'منتج جديد',
            
            'Drivers' => 'السائقين',
            'drivers' => 'السائقين',
            'Shipping rate' => 'معدل التوصيل',
            'shipping rate' => 'معدل التوصيل',
            
            //
            
            'Shop Location' => 'موقع المتجر',
            
            'Top selling' => 'الأكثر مبيعا',
            'Order per city' => 'الطلب حسب المدينة',
            'Active drivers' => 'السائقين النشطين',
            'Driver name' => 'اسم السائق',
            'No. Of Orders' => 'عدد الطلبات',
            'Sales per month' => 'المبيعات في الشهر',
            
            
            'My Products' => 'منتجاتي',
            'Filter' => 'تصفية',
            'Name' => 'الاسم',
            'Offer' => 'العرض',
            'Sponsor' => 'معلن',
            'Price' => 'السعر',
            'Quantity' => 'الكمية',
            'Edit product' => 'تعديل المنتج',
            'General' => 'معلومات عامة',
            'Product name' => 'اسم المنتج',
            'Description' => 'الوصف',
            
            'Custom' => 'الخيار',
            'Extra-Cost' => 'مبلغ إضافي',
            'Color' => 'اللون',
            'Title' => 'العنوان',
            'Add custom' => 'إضافة الخيار',
            'Product Images' => 'صور المنتج',
            'Add files' => 'إضافة ملفات',
            'Cancel upload' => 'إلغاء الرفع',
            
            'Start' => 'بدء',
            'Cancel' => 'إلغاء',
            '' => '',
            '' => '',
            // {{trans(lang_app_site().'.CP.')}}
            'Save Product' => 'حفظ المنتج',
            
        ] 
        
        
        
    ],
    
    
];
/**
 * return [
 * 'notifications' => [
 * 'user_approved' => 'Your account has been approved.', تم تفعيل حسابك
 * 'user_disabled' => 'Your account has been disabled.',  تم تعطيل حسابك من الادارة
 * 'send_order' => 'New order.',   طلب جديد
 * 'accept_order' => 'Your order was accepted.', تمت الموافقة على طلبك
 * 'reject_order' => 'Your order was rejected :message.', تم رفض طلبك
 * 'canceled_order' => 'Order was canceled.',  تم الغاء الطلب
 * 'finished_order' => 'Client confirmed the procurement process.',  تم تأكيد عملية التسليم من الزبون
 * 'accepted_driver' => 'Driver accepted your request.' ,  قام السائق بالموافقة على طلب التوصيل
 * 'rejected_driver' => 'Driver rejected your request.',  قام السائق برفض طلب التوصيل
 * 'start_navigation' => 'Driver starting the order delivery.',   تم البدء بتوصيل الطلب
 * 'pickup_driver' => 'Driver reached the pickup location.', تم وصول السائق لمكان استلام الطلب
 * 'drop_off_driver' => 'Driver reached the drop-off location.',   تم وصول السائق لمكان التسليم
 * 'rate_product' => 'Client has rated the product.', قام الزبون بتقييم المنتج
 * 'rate_service' => 'Client has rated the service.',   قام الزبون بتقييم الخدمة
 * 'send_service' => 'Client send service order.', تم ارسال طلب خدمة من الزبون
 * 'accepted_request' => 'Service\'s request was accepted.', تمت الموافقة على طلب الخدمة
 * 'rejected_request' => 'Your service\'s order was rejected :message.', تم رفض طلب الخدمة
 * 'canceled_request' => 'Client was canceled the request.', تم الغاء الطلب من الزبون
 * 'finished_request' => 'Your request was finished.',  تم انهاء الطلب
 * 'assign_driver' => 'The admin assigned you to the new request.', تم تحويل طلب جديد لك من الادارة
 * 'notify_merchant_assign_driver' => 'Your order assigned to driver :driver_name.', تم تعيين طلبك للسائق :
 * 'chat' => 'New message.' رسالة جديدة
 * ],
 *
 * 'site' => [
 * 'home' => [
 * 'categories' => 'categories' التصنيفات,
 * 'arabic' => 'Arabic',  لغة عربية
 * 'register' => 'Register'  التسجيل,
 * 'login' => 'Sign in', تسجيل دخول
 * 'logout' => 'Log out',   تسجيل خروج
 * 'all_categories' => 'All categories', التصنيفات
 * 'search' => 'Search...',  بحث
 * 'callus' => 'Call us now', تواصل معنا الان
 *
 * 'home' => 'Home',  الرئيسية
 * 'merchants' => 'Merchants',  المحلات
 * 'services' => 'Services',  الخدمات
 * 'about_us' => 'About us',  من نحن
 * 'contact_us' => 'Contact us',  تواصل معنا
 * 'all_cats' => 'All categories',  جميع التصنيفات
 *
 * 'popular_products' => 'Popular products',  منتجات شائعة
 * 'new_products' => 'New products', منتجات جديدة
 * 'top_selling' => 'Top selling', اكثر مبيعا
 * 'view_all' => 'View All', عرض الكل
 * 'sar' => 'SAR', ريال سعودي
 *
 * ],
 * 'product' => [
 * 'quick_view' => 'Quick View',  عرض سريع
 * 'add_to_cart' => 'ADD TO CART', اضف الى الع
 * ]
 * ]*/
